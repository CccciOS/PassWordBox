//
//  PassWordCollectionViewCell.h
//  CcDemo
//
//  Created by 崔璨 on 2017/8/9.
//  Copyright © 2017年 cccc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PassWordCollectionViewCell : UICollectionViewCell
//@property (strong, nonatomic) IBOutlet UIImageView *circleImageV;
//@property (strong, nonatomic) IBOutlet UIView *lineV;
@property (strong, nonatomic)  UIImageView *circleImageV;
@property (strong, nonatomic)  UIView *lineV;
@end
